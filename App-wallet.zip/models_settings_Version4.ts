export type CryptoOperation = "send" | "swap" | "trade" | "sell";
export type CryptoFee = {
  name: string;
  amount: number;
  active: boolean;
};
export type OperationSettings = {
  enabled: boolean;
  fee: CryptoFee;
};
export interface AdminSettings {
  operations: Record<CryptoOperation, OperationSettings>;
  cryptoFees: CryptoFee[];
  plans: Record<string, number>;
  chatType?: string;
  whatsappNumber?: string;
  telegramUser?: string;
  messengerLink?: string;
  customWidgetCode?: string;
  walletAddress?: string;
  fees?: Record<string, any>;
}