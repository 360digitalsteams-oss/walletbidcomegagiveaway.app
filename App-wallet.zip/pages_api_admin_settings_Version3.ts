let settings = {
  operations: {
    send: { enabled: true, fee: { name: "network", amount: 1, active: true } },
    swap: { enabled: true, fee: { name: "swap", amount: 2, active: true } },
    trade: { enabled: true, fee: { name: "trade", amount: 3, active: true } },
    sell: { enabled: true, fee: { name: "sell", amount: 1.5, active: true } }
  },
  cryptoFees: [
    { name: "network", amount: 1, active: true },
    { name: "BTC", amount: 6, active: true },
    { name: "ETH", amount: 4, active: true },
    { name: "USDT", amount: 1, active: true },
    { name: "BNB", amount: 2, active: true },
    { name: "SOL", amount: 1.2, active: true },
    { name: "XRP", amount: 0.9, active: true }
  ],
  plans: {
    Basic: 0, Silver: 50, Gold: 100, Platinum: 250, Diamond: 500
  },
  chatType: "whatsapp",
  whatsappNumber: "+1234567890",
  walletAddress: "bc1qxy...."
};

export default function handler(req, res) {
  if (req.method === "GET") {
    res.json(settings);
  } else if (req.method === "PUT") {
    settings = { ...settings, ...req.body };
    res.json(settings);
  }
}