let clients = [
  { id: 1, name: "Jordan Okad", email: "jordan@example.com", wallet: "bc1qxy...", balance: 1.2, status: "active", activeFees: [], plan: "Basic" },
  { id: 2, name: "Linda Park", email: "linda@example.com", wallet: "1A1zP1...", balance: 0.8, status: "pending", activeFees: [], plan: "Silver" },
];

export default function handler(req, res) {
  if (req.method === "GET") {
    res.json(clients);
  } else if (req.method === "PUT") {
    const id = Number(req.query.id);
    const idx = clients.findIndex(c => c.id === id);
    if (idx !== -1) {
      clients[idx] = req.body;
      res.json(clients[idx]);
    } else {
      res.status(404).send("Client not found");
    }
  }
}