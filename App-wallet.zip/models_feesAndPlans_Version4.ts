export type FeeType = "gas" | "bitcoin" | "swap" | "signal";
export type PlanType = "Basic" | "Silver" | "Gold" | "Platinum" | "Diamond";

export interface Fee {
  type: FeeType;
  amount: number;
  active: boolean;
}

export interface Plan {
  name: PlanType;
  price: number;
  features: string[];
}

export interface Client {
  id: number;
  name: string;
  email: string;
  wallet: string;
  balance: number;
  status: string;
  activeFees: FeeType[];
  plan: PlanType;
}